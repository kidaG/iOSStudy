//
//  MyDictionary-Bridging-Header.h
//  MyDictionaryApps
//
//  Created by yuya on 2015/11/19.
//  Copyright © 2015年 yuya. All rights reserved.
//

#ifndef MyDictionary_Bridging_Header_h
#define MyDictionary_Bridging_Header_h

#import "UIImageView+WebCache.h"


#endif /* MyDictionary_Bridging_Header_h */
