//
//  LTMorphingLabel.h
//  LTMorphingLabel
//
//  Created by Lex Tang on 1/8/15.
//  Copyright (c) 2015 lexrus.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LTMorphingLabel.
FOUNDATION_EXPORT double LTMorphingLabelVersionNumber;

//! Project version string for LTMorphingLabel.
FOUNDATION_EXPORT const unsigned char LTMorphingLabelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LTMorphingLabel/PublicHeader.h>


