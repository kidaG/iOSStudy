//
//  User.swift
//  CoreDataFeature
//
//  Created by yuya on 2015/11/16.
//  Copyright © 2015年 yuya. All rights reserved.
//

import Foundation
import CoreData

class Users: Records {

    struct Constant{
        static let TableName = "Users"
    }

}
